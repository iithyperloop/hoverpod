var searchData=
[
  ['omega',['omega',['../structvn_1_1sensors_1_1_velocity_compensation_status_register.html#a2641a5769ae6c8f99400a992c4b06c0d',1,'vn::sensors::VelocityCompensationStatusRegister']]]
];
